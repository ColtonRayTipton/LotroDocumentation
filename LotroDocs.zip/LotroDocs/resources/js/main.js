$().ready(function(){
    $(".frameset").splitter({
        splitVertical: true,
        reizeToWidth: true,
        sizeLeft: 0,
    });
});